<?php
if (function_exists('phpversion')) {
    echo '<h2 align="center">' . $_SERVER['REQUEST_SCHEME'] . '://' . $_SERVER['SERVER_NAME'] . '</h2>';
    echo '<h2 align="center">' . __FILE__ . '</h2>';
    phpinfo();
}
?>